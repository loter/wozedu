-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 24, 2014 at 11:42 AM
-- Server version: 5.1.73
-- PHP Version: 5.3.3

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT=0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `weblux_md_task1`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) NOT NULL,
  `user_username` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_type` int(1) unsigned NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_username` (`user_username`),
  KEY `user_type` (`user_type`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='users table' AUTO_INCREMENT=30 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `user_username`, `user_password`, `user_email`, `user_type`) VALUES
(4, 'dragomir', 'loterel', '40d3008da93acbb8222f6bcbc226522e', 'loter200@yahoo.co.uk', 1),
(5, 'Dragomir Enachi', 'loter001', '40d3008da93acbb8222f6bcbc226522e', 'loter200@yahoo.co.uk', 2),
(6, 'Dragomir Enachi', 'loter002', '40d3008da93acbb8222f6bcbc226522e', 'loter200@yahoo.co.uk', 1),
(7, 'Dragomir Enachi', 'loter003', '40d3008da93acbb8222f6bcbc226522e', 'loter200@yahoo.co.uk', 3),
(8, 'Dragomir Enachi', 'loter005', '40d3008da93acbb8222f6bcbc226522e', 'loter200@yahoo.co.uk', 2),
(9, 'Dragomri Enachi', 'loter006', '40d3008da93acbb8222f6bcbc226522e', 'loter200@yahoo.co.uk', 3),
(10, 'Dragomri Enachi', 'loter007', '40d3008da93acbb8222f6bcbc226522e', 'loter200@yahoo.co.uk', 3),
(11, 'Dragomri Enachi', 'loter008', '40d3008da93acbb8222f6bcbc226522e', 'loter200@yahoo.co.uk', 3),
(12, 'Dragomri Enachi', 'loter009', '40d3008da93acbb8222f6bcbc226522e', 'loter200@yahoo.co.uk', 1),
(13, 'Dragomir Enachi', 'loter010', '40d3008da93acbb8222f6bcbc226522e', 'loter200@yahoo.co.uk', 2),
(14, 'Dragomir Enachi', 'loter011', '40d3008da93acbb8222f6bcbc226522e', 'loter200@yahoo.co.uk', 2),
(15, 'Dragomir Enachi', 'loter012', '40d3008da93acbb8222f6bcbc226522e', 'loter200@yahoo.co.uk', 1),
(16, 'Dragomir Enachi', 'loter013', '40d3008da93acbb8222f6bcbc226522e', 'loter200@yahoo.co.uk', 1),
(17, 'Dragomir Enachi', 'loter014', '40d3008da93acbb8222f6bcbc226522e', 'loter200@yahoo.co.uk', 1),
(18, 'Dragomir Enachi', 'loter015', '40d3008da93acbb8222f6bcbc226522e', 'loter200@yahoo.co.uk', 1),
(19, 'Dragomir Enachi', 'loter017', '40d3008da93acbb8222f6bcbc226522e', 'loter200@yahoo.co.uk', 1),
(20, 'Dragomir Enachi', 'loter016', '40d3008da93acbb8222f6bcbc226522e', 'loter200@yahoo.co.uk', 1),
(21, 'loter020', 'loter020', '1db1142c2d166956a932a9216793d27b', 'loter200@yahoo.co.uk', 1),
(22, 'loter021', 'loter021', 'c685fe96350053c173f774f99eff0e6c', 'loter200@yahoo.co.uk', 1),
(23, 'loter022', 'loter022', '90ef7d8b4c70ff63e6b64067ebe28555', 'loter200@yahoo.co.uk', 2),
(24, 'loter023', 'loter023', 'd5fe359637674567e612383cff45203f', 'loter200@yahoo.co.uk', 3),
(25, 'loter024', 'loter024', '40d3008da93acbb8222f6bcbc226522e', 'loter200@yahoo.co.uk', 1),
(29, 'loter024', 'loter025', '2ce18b59a47a0a66f0aa8654851449cf', 'loter024@asdasd.com', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_types`
--

CREATE TABLE IF NOT EXISTS `user_types` (
  `user_type_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_type_name` varchar(255) NOT NULL,
  PRIMARY KEY (`user_type_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `user_types`
--

INSERT INTO `user_types` (`user_type_id`, `user_type_name`) VALUES
(1, 'Admin'),
(2, 'Reseller'),
(3, 'Client');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`user_type`) REFERENCES `user_types` (`user_type_id`) ON UPDATE CASCADE;
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
